 <!DOCTYPE html> <html lang="en-US" xmlns:fb="http://www.facebook.com/2008/fbml" xmlns="http://www.w3.org/1999/xhtml"> <head>  <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>File sharing and storage made simple</title>
<META NAME="keywords" CONTENT="online storage, free storage, cloud Storage, collaboration, backup file Sharing, share Files, photo backup, photo sharing, ftp replacement, cross platform, remote access, mobile access, send large files, recover files, file versioning, undelete, Windows, PC, Mac, OS X, Linux, iPhone, iPad, Android" />
<META NAME="description" CONTENT="MediaFire is a simple to use free service that lets you put all your photos, documents, music, and video in a single place so you can access them anywhere and share them everywhere." />
<META NAME="ROBOTS" CONTENT="NOINDEX,NOFOLLOW" />
<META NAME="GOOGLEBOT" CONTENT="NOINDEX,NOFOLLOW" />
<META NAME="SLURP" CONTENT="NOINDEX,NOFOLLOW" />
<meta name="google-translate-customization" content="5587c1b0a958bf07-62a8e309de686e87-gc92f61279a2c8524-11"></meta>
<meta http-equiv="Cache-Control" content="no-store, no-cache, must-revalidate, post-check=0, pre-check=0" />
<meta http-equiv="Pragma" content="no-cache" />
<meta http-equiv="Expires" content="0" />
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<meta property="og:image" content="https://www.mediafire.com/images/logos/mf_logo250x250.png" />
<meta property="twitter:image" content="https://www.mediafire.com/images/logos/mf_logo250x250.png" />
<meta property="og:title" content="MediaFire" />
<meta property="twitter:title" content="MediaFire" />
<meta property="og:description" content="MediaFire is a simple to use free service that lets you put all your photos, documents, music, and video in a single place so you can access them anywhere and share them everywhere." />
<meta property="twitter:description" content="MediaFire is a simple to use free service that lets you put all your photos, documents, music, and video in a single place so you can access them anywhere and share them everywhere." />
<meta property="og:type" content="website" />
<meta property="og:site_name" content="MediaFire" />
<meta property="og:url" content="https://www.mediafire.com" />
<meta property="fb:app_id" content="124578887583575" />

<!-- iOS 6 smart banner -->
<meta name="apple-itunes-app" content="app-id=555646196" />

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<!-- MSIE 10 -->
<meta name="msapplication-TileColor" content="#2C86DB">
<meta name="msapplication-TileImage" content="favicon.png">
  <link href="//static.mediafire.com/css/mfv3_121967.php?ver=ssl" rel="stylesheet" type="text/css"/> <link href="//static.mediafire.com/css/mfv4_121967.php?ver=ssl&date=2026-05-08" rel="stylesheet" type="text/css"/>  <link href='https://fonts.googleapis.com/css?family=Open+Sans:800,700,400,300' rel='stylesheet' type='text/css'/>  <!--[if lte IE 8]> <link rel="stylesheet" type="text/css" href="//static.mediafire.com/css/ie.css_121967.php?ver=ssl"/> <![endif]--> <!--[if lt IE 7]> <link rel="stylesheet" type="text/css" href="//static.mediafire.com/css/ie6.css_121967.php?ver=ssl"/> <![endif]--> <!--[if IE 7]> <link rel="stylesheet" type="text/css" href="//static.mediafire.com/css/ie7.css_121967.php?ver=ssl"/> <![endif]-->  <link rel="icon" href="/favicon.ico"/>  <script>
    // Recaptcha event bus
    const mfRecaptchaBus = new EventTarget();
    function onMfRecaptchaLoad() {
        mfRecaptchaBus.dispatchEvent(new Event('ready'));
    }
    function onMfRecaptchaSuccess(token) {
        mfRecaptchaBus.dispatchEvent(new CustomEvent('solved', { detail: { token } }));
    }
    function onMfRecaptchaExpired() {
        mfRecaptchaBus.dispatchEvent(new Event('expired'));
    }
</script>
<script src="https://www.google.com/recaptcha/api.js?onload=onMfRecaptchaLoad&render=explicit" async defer></script> <script type="text/javascript">var acK= true;var aCH='live';var aWJ= false;function asO(e,qv){var vU=qv+': ';if(e.name){vU+='Error name: "'+e.name+'"  ';}if(e.message){vU+='Error message: "'+e.message+'"  ';}Ku(5,vU);};var Iu='File sharing and storage made simple'; </script>  <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"> </script>  <script language="JavaScript" type="text/JavaScript">try{if(typeof jQuery=="undefined"){document.write('<scri'+'pt type="text/javascript" src="//static.mediafire.com/js/jquery/1.7.2/jquery.min.js"></sc'+'ript>');}}catch(e){asO(e,'HDR:jquery_check');} </script>   <style type="text/css">  </style> <script type="text/javascript">var JS_LoadTime= 121967;var sDefaultShareLinkProtocol='https';window.onload=function(){Cy();}; </script>  
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-829541-1"></script>
    <script>
        try {
            window.dataLayer = window.dataLayer || [];
            function gtag(){dataLayer.push(arguments);}
            gtag("js", new Date());
            gtag("config", "UA-829541-1", {"dimension1":"unregistered","dimension7":"legacy","dimension8":"\/100\/"});
        } catch(e) {}
    </script>
    
    <script type="text/javascript">
    (function(e,t){var n=e.amplitude||{_q:[],_iq:{}};var r=t.createElement("script")
    ;r.type="text/javascript"
    ;r.integrity="sha384-tzcaaCH5+KXD4sGaDozev6oElQhsVfbJvdi3//c2YvbY02LrNlbpGdt3Wq4rWonS"
    ;r.crossOrigin="anonymous";r.async=true
    ;r.src="https://cdn.amplitude.com/libs/amplitude-8.5.0-min.gz.js"
    ;r.onload=function(){if(!e.amplitude.runQueuedFunctions){
    console.log("[Amplitude] Error: could not load SDK")}}
    ;var i=t.getElementsByTagName("script")[0];i.parentNode.insertBefore(r,i)
    ;function s(e,t){e.prototype[t]=function(){
    this._q.push([t].concat(Array.prototype.slice.call(arguments,0)));return this}}
    var o=function(){this._q=[];return this}
    ;var a=["add","append","clearAll","prepend","set","setOnce","unset","preInsert","postInsert","remove"]
    ;for(var c=0;c<a.length;c++){s(o,a[c])}n.Identify=o;var u=function(){this._q=[]
    ;return this}
    ;var l=["setProductId","setQuantity","setPrice","setRevenueType","setEventProperties"]
    ;for(var p=0;p<l.length;p++){s(u,l[p])}n.Revenue=u
    ;var d=["init","logEvent","logRevenue","setUserId","setUserProperties","setOptOut","setVersionName","setDomain","setDeviceId","enableTracking","setGlobalUserProperties","identify","clearUserProperties","setGroup","logRevenueV2","regenerateDeviceId","groupIdentify","onInit","logEventWithTimestamp","logEventWithGroups","setSessionId","resetSessionId"]
    ;function v(e){function t(t){e[t]=function(){
    e._q.push([t].concat(Array.prototype.slice.call(arguments,0)))}}
    for(var n=0;n<d.length;n++){t(d[n])}}v(n);n.getInstance=function(e){
    e=(!e||e.length===0?"$default_instance":e).toLowerCase()
    ;if(!Object.prototype.hasOwnProperty.call(n._iq,e)){n._iq[e]={_q:[]};v(n._iq[e])
    }return n._iq[e]};e.amplitude=n})(window,document);

    var amp = amplitude.getInstance();
    amp.init('28916b6cd60c79c0447b3c23ad698c98');
    if ('') amp.setUserId('7d8e227e283c6630');
    amp.setUserProperties({group: '1'});
    </script><!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-53LP4T');</script>
<!-- End Google Tag Manager -->  <script type="text/javascript">var MYF_WIDGET_STORAGE_totalStorage= 10737418240;MYF_WIDGET_STORAGE_usedStorage= 0;MYF_WIDGET_STORAGE_usedStoragePercent=Math.round(Math.min(parseFloat(MYF_WIDGET_STORAGE_usedStorage/MYF_WIDGET_STORAGE_totalStorage),1)*100),MYF_STORAGE_bAdFreeDownloadPremiumUser= false,aXq= false,aXm= false,aWh="",aXE= 0,aWx= false,aXd='4.50',window.addEventListener('onload',function(){aXa();}); </script>   <link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png"/> <meta name="msapplication-TileColor" content="#0077ff"> <meta name="theme-color" content="#0077ff"> <link rel="icon" type="image/vnd.microsoft.icon" href="/favicon.ico"/> <script type="text/javascript">try{window.addEventListener('DOMContentLoaded',function(){document.body.addEventListener('touchstart',function(){},{passive:true});});}catch(e){} </script> </head> <body class=" freeAccount darkTheme"> <!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-53LP4T"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->  <div id="statusmessage" name="statusmessage" style="display:none;"> <div style="width:600px;margin:auto;padding:10px;opacity:0.95;"> <div class="statusmessage_wrapper" style="padding:20px;text-align:center;"> <div id="statusmessage_text" name="statusmessage_text" aria-live="rude"></div> <div id="dismiss_message_div"> Click to dismiss this message </div> </div> </div> </div>  <div role="dialog" id="modal_window_popup" style="display:none" class="popup"> <a role="button" title="Close dialog" href='#' OnClick="bfM('modal_window_popup');return false;" id="modal_window_closer" class="popup-close"><span style="display:none;">Close Popup</span></a> <div class="modalMsgWrapper" style=""> <iframe name="modal_msg_iframe" id="modal_msg_iframe" src="/blank.html" frameborder="0" allowTransparency="true"></iframe> </div> </div>  <div role="dialog" id="uploader_window_popup" style="display:none" class="popup"> <a role="button" title="Close dialog" href='#' OnClick="bfM('uploader_window_popup');return false;" id="uploader_window_closer" class="popup-close"><span style="display:none;">Close Popup</span></a> <div class="modalMsgWrapper" style=""> <iframe name="uploader_msg_iframe" id="uploader_msg_iframe" src="/blank.html" scrolling="no" frameborder="0"></iframe> </div> </div>  <div id="notify_main" class="msg_default msg_size1" style="display:none;" onclick="Qv(event);" onmouseover="if(!NH&& !NB)OI(4);NH=true;" onmouseout="NH=false;"> <div class="notify_msgwrapper" aria-live="rude"> <p> <span id="notify_msgtitle_min" class="notify_msgtitle_min">100 Recent Messages</span> <span id="notify_msgtitle" class="notify_msgtitle">Message title goes here</span> <span id="notify_msgbody" class="notify_msgbody">Short paragraph explaining the nature of the message goes here.</span> </p> </div> <div id="notify_msgscroll" class="notify_msgscroll"> <a class="msgscroll_up" href="#" onclick="Pf();return false;"><span style="display:none;">Scroll up</span></a> <a class="msgscroll_dn" href="#" onclick="Pe();return false;"><span style="display:none;">Scroll down</span></a> <p id="notify_msgnumber" class="msgnumber"></p> </div> </div>  <div class="upgrade_your_browser"> <div class="wrap"> It appears you are using an older browser. For a better experience when using MediaFire, we recommend you <a href="#" style="color:#fff;text-decoration:underline;cursor:pointer;" onclick="LoadIframeLightbox('/dynamic/template_popup.php?page=upgrade_browser',680,300);return false;">upgrade your browser</a>. </div> </div> <div id="container" class="   ">  <div id="helpContainer" class="floatingTabsBox">  <form id="" class="helpForm open" action="" style=""> <p> Questions? <a href="/help/submit_a_ticket.php" target="_blank">Submit a ticket</a> or <a href="/help/" target="_blank">visit our Help Center</a>. </p> <p class="additionalHelpLinks">Additional help links: <a href="/help/submit_a_ticket.php" target="_blank">Contact Us</a> </p> <button type="button" class="expandHelpClose" onClick="$('#helpContainer').removeClass('expandHelp');"> Close </button> </form> </div>  <div id="content_container"> <a name="top"></a>  <header id="header" role="banner" >    <div class="wrap" style="position:relative;"> <h1 class="logo">  <a href="/" target="_top" title="MediaFire"> <img alt="MediaFire" width="180" style="max-height:25px" id="mf_logo_full_color_reversed" src="//static.mediafire.com/images/backgrounds/header/mf_logo_u1_full_color_reversed.svg"/> <img alt="MediaFire" width="180" style="max-height:25px" id="mf_logo_full_color" src="//static.mediafire.com/images/backgrounds/header/mf_logo_u1_full_color.svg"/> </a>  </h1>     <iframe class="upgrade_button_frame" src="/templates/upgrade/upgrade_button.php" frameborder="0" scrolling="no" title="Upgrade"></iframe>  <div id="secondaryHeaderNav" class="nav" >  <button type="button" class="Btn Btn--primary HeaderHelpButton" title="Click for help" onClick="$('#helpContainer').toggleClass('expandHelp');" style="margin-right:10px;"> <i class="Btn-icon Btn-icon--white Btn-icon--help"></i> <span>Help</span> </button> </div>    <div id="logged_in_info" class="login_inprogress" >  <div class="dropdown dropdownOnClick ddRight cf"> <a id="loggedin" class="prelogin" title="Logged in as " href="javascript:void(0);"> <span class="smArrowDown"></span> <span id="avatar-icon" class="Header-avatar">  <span><img src="https://www.mediafire.com/images/icons/myfiles/default.png" style="width: 32px; height: 32px" alt="User Avatar" /></span> </span> </a>  <ul id="loggedin_dropdown">  <li class="ddStaticTxt MainMenu-name"> </li>  <li class="ddStaticTxt MainMenu-email"><div></div></li>  <li class="ddStaticTxt">  </li>       <li class="divider"></li> <li> <a href="/" class="MainMenu-myFiles"> <i class="Btn-icon Btn-icon--folder"></i> My Files </a> </li> <li> <a href="/myaccount" class="MainMenu-settings"> <i class="Btn-icon Btn-icon--settings"></i> Settings </a> </li>  <li> <a href="/upgrade/" class="MainMenu-upgrade"> <i class="Btn-icon Btn-icon--upgrade"></i> Upgrade </a> </li>   <li> <a href="/earnspace/" class="MainMenu-earnSpace"> <i class="Btn-icon Btn-icon--plus"></i> Earn free space! </a> </li>  <li> <a href="/software/" class="MainMenu-mobile"> <i class="Btn-icon Btn-icon--mobile"></i> Mobile </a> </li>  <li> <a href="#" class="MainMenu-logout" OnClick="dO();return false;"> <i class="Btn-icon Btn-icon--logout"></i> Log Out </a> </li> </ul> </div>  <div id="notloggedin_wrapper" class="hide"> <div id="notloggedin" class="prelogin"> <div id="login_signup" data-redirect="true"> <a href="/upgrade/" class="SignupBtn Btn Btn--primary Btn--roundedLeft" title="Sign up" style="border-right:1px solid #0045AD;"> <span>Sign Up</span> </a> <a href="/login/" class="LoginBtn Btn Btn--primary Btn--roundedRight" title="Log in"> <span>Log In</span> </a> </div> </div> </div> </div> </div>    </header>  <div id="fb-root"></div>  <script type="text/javascript">$('.floatingTab').click(function(e){if($(this).hasClass('open')){$(this).removeClass('open');$(this).parent().animate({right: -380},250,'easeOutExpo');}else{$(this).addClass('open');$(this).parent().animate({right:0},700,'easeOutExpo');}});$('.floatingTabsButtons .cancelBtn').click(function(e){$('.floatingTab').removeClass('open');$(this).parent().parent().animate({right: -380},250,'easeOutExpo');}); </script>    <script language="JavaScript" src="//static.mediafire.com/js/master_121967.js" type="text/javascript"> </script> <script language="JavaScript" type="text/JavaScript">bkA='iwvu9o77lau';identifier='';UserLogin='0';UserEmail='n/a';fu= 0;lB= 1;if(lB==1)var bdq='https';else var bdq='http';var WRInitTime=(new Date()).getTime();var wM= 0;var wL= 0;var bLinkedFacebook= 0;var bLinkedTwitter= 0;var FBAppId='124578887583575';var FBAPIVersion='v24.0/';var yO= 120000;var yP= 120000;var mI;try{jQuery(function($){function aaP(abv){return abv.replace(/\W+/,"-").toLowerCase();};FHI_FadeTimer=null,FHI_FadeDelay=2000,FHI_DisableTimerCount=false,FHI_IconsWrapper=$("body.myfiles #subFooterWrap, body.filePreview #subFooterWrap, body.fileEdit #subFooterWrap");FHI_HideFooterHelpIcons=function(){if(!FHI_DisableTimerCount&& !$("#footer").hasClass("tabMF")&& !$("#footer").hasClass("tabMFhelp")){FHI_IconsWrapper.fadeOut("slow");}};$("body").bind("mousemove.fhi",function(){FHI_IconsWrapper.fadeIn("fast");clearTimeout(FHI_FadeTimer);if(!FHI_DisableTimerCount&& !$("#footer").hasClass("tabMF")&& !$("#footer").hasClass("tabMFhelp")){FHI_FadeTimer=setTimeout(FHI_HideFooterHelpIcons,FHI_FadeDelay);}});FHI_IconsWrapper.on("mouseenter.fhi",function(){FHI_DisableTimerCount=true;}).on("mouseleave.fhi",function(){FHI_DisableTimerCount=false;});var Jd=BrowserName();if(Jd==="Internet Explorer"){document.body.className=document.body.className.replace(/(\sie\d+|^ie\d+)/g,'');Jd="ie"+parseInt(Bm(),10);}if(Jd==="Opera"&&parseInt(Bm(),10)>=15){Jd="newOpera";}$(document.body).addClass(aaP(lc())+" "+aaP(Jd));$('#form_login1').keydown(function(e){e=e||window.event;if(e.keyCode==13&&($('#login_pass').val()!=''||$('#login_email').val()!='')){$(this).closest('form').submit();return false;}});$("#page_screen").on("click",QU);});}catch(e){asO(e,'HDR:os_browser_check');} </script> <script type="text/javascript">try{$(document).ready(function(){  aoy("free,pro,biz,tools");   });}catch(e){asO(e,'HDR:show_menu');}$("#loggedin_dropdown .MainMenu-settings:contains('Settings')").click(function(){if(parent&&parent.Rz){parent.Rz('settings');return false;}return true;});$("#loggedin_dropdown .MainMenu-myFiles:contains('My Files')").click(function(){if(parent&&parent.Rz){parent.Rz('myfiles');return false;}return true;}); </script> <script type="text/javascript">try{setInterval(function(){if(aL('mfloggedoff')=='true'){window.localStorage&&localStorage.clear();top.location='/logout.php';}},30000);}catch(e){} </script>  <script type="text/javascript">document.addEventListener('keydown',function(e){if(e.keyCode===9){$('body').addClass('show-focus-outlines');}});document.addEventListener('click',function(e){$('body').removeClass('show-focus-outlines');}); </script>  
<script type="text/javascript">
    var iCountDown = 5;

    UpdateCountDown();

    var xInterval = setInterval(function () {
        if (--iCountDown) {
            UpdateCountDown();
        } else {
            clearInterval(xInterval);

            SwitchMessage();

            setTimeout(function () {
                window.location = '/file/13v2dkfa9ipyyyh/rocm-7.12.0.dev0.tar.gz/file';
            }, 2500);
        }
    }, 1000);

    function UpdateCountDown() {
        var eElement = null;

        if (eElement = document.getElementById('count-down')) {
            eElement.innerHTML = iCountDown;
        }
    }

    function SwitchMessage () {
        var eElement = null;

        //if (eElement = document.getElementById('download_repair_wrapper')) {
        //    eElement.style.backgroundImage = "url('')";
        //} -- keep, might need later, gabe

        if (eElement = document.getElementById('failure_msg')) {
            eElement.style.display = 'none';
        }

        if (eElement = document.getElementById('dlrestart_msg')) {
             eElement.style.display = 'block';
        }
    }
</script>


<div id="download_repair_wrapper" class="DownloadRepair">
        <div id="failure_msg">
        <div id="dlRepairMessage2" class="DownloadRepair-generateKeyMessage">
            <h2 class="DownloadRepair-title">Generating new download key</h2>
            <p>
                We are generating a new download key for this file.
                <span class="DownloadRepair-instructionText">Click the button below to continue.</span>
            </p>
            <a class="gbtnPrimary DownloadRepair-continueDelay">
                <span class="tooltip point-down">You must wait 5 seconds before continuing.</span>
                <span class="DownloadRepair-continueDelayText">Continue</span>
            </a>
            <a href="/file/13v2dkfa9ipyyyh/rocm-7.12.0.dev0.tar.gz/file"
               id="continue-btn"
               title="You must wait 5 seconds before continuing."
               class="gbtnTertiary DownloadRepair-continue"
               rel="nofollow">
               Continue
            </a>
            <script>
                // Do not delay button for a 5 second countdown
                var iCountDown = 5;
                var eButton = document.getElementById('continue-btn');
                var eInstructionText = document.getElementsByClassName('DownloadRepair-instructionText')[0];
                var eDisabledButton = document.getElementsByClassName('DownloadRepair-continueDelay')[0];
                var eEnabledButton = document.getElementsByClassName('DownloadRepair-continue')[0];

                // 30 second timer
                if (iCountDown === 30) {
                    // Show the disabled button immediately for a 5 second timer
                    eDisabledButton.style.display = 'inline-block';
                    eEnabledButton.style.display = 'none';
                    // Enable continue button and hide disabled button after timer
                    setTimeout(function() {
                        eEnabledButton.style.display = 'inline-block';
                        eDisabledButton.style.display = 'none';
                        eInstructionText.style.display = 'inline';
                    }, 5000);

                // 5 second timer
                } else {
                    eEnabledButton.style.display = 'inline-block';
                    eInstructionText.style.display = 'inline';
                }
            </script>
        </div>
        <b class="DownloadRepair-timer">
            Restarting download in:
            <span id="count-down">
                5            </span>
            seconds
        </b>
            </div>
    <div id="dlrestart_msg" class="DownloadRepair-restarting">
        Your download is restarting&hellip;
    </div>
    </div>


<div style="text-align: center; padding: 0 20px;">
    <p>
        If you are encountering problem with downloads, we request that you complete a diagnostic test through our <a href="/customer_diagnosis/questionnaire.php">Upload/Download Diagnostic Tool</a>.
    </p>
</div>

 <div style="clear:both;"></div> </div> </div>   <footer id="footer" class="footer" role="contentinfo"> <div class="wrap" id="mainFooterWrap"> <div class="footerColWrap cf"> <div class="footerCol"> <h2><a href="/about/">Company</a></h2> <ul> <li class="minFooterShow"><a href="/about/">About Us</a></li> <li><a href="/about/jobs.php">Careers</a></li> <li><a href="/press/">Press</a></li> <li><a href="https://blog.mediafire.com/" target="_blank">Company Blog</a></li> </ul> </div> <div class="footerCol"> <h2><a href="/software/index.php">Tools</a></h2> <ul> <li class="minFooterShow"> <a href="/software/mobile/">MediaFire Mobile</a> </li>  <li class="minFooterShow"> <a href="https://www.fast.io/?utm_source=mfftr_download_r" title="Fast.io - File Sharing and Cloud Storage for Teams" target="_blank" rel="noopener noreferrer" aria-label="Fast.io - Team File Sharing and Cloud Storage for Small Businesses">Cloud Storage for Teams</a> </li>  </ul> </div>  <div class="footerCol"> <h2><a href="https://www.fast.io/alternatives?utm_source=mfftr_download_r">Compare</a></h2> <ul> <li class="minFooterShow"> <a href="https://www.fast.io/alternatives/dropbox?utm_source=mfftr_download_r" title="Best Dropbox alternative - Fast.io" target="_blank" rel="noopener noreferrer" aria-label="Best Dropbox alternative - Fast.io">Dropbox Alternative</a> </li> <li class="minFooterShow"> <a href="https://www.fast.io/alternatives/box?utm_source=mfftr_download_r" title="Best Box.com alternative - Fast.io" target="_blank" rel="noopener noreferrer" aria-label="Best Box.com alternative - Fast.io">Box.com Alternative</a> </li> <li class="minFooterShow"> <a href="https://www.fast.io/alternatives/google-drive?utm_source=mfftr_download_r" title="Best Google Drive alternative - Fast.io" target="_blank" rel="noopener noreferrer" aria-label="Best Google Drive alternative - Fast.io">Google Drive Alternative</a> </li> </ul> </div>  <div class="footerCol"> <h2><a href="/upgrade/">Upgrade</a></h2> <ul> <li><a href="/upgrade/index.php?plan=Pro">Professional</a></li>  <li><a href="https://www.fast.io/?utm_source=mffooter">Business</a></li>  </ul> </div> <div class="footerCol" style="margin-right:0;"> <h2><a href="https://mediafire.zendesk.com/hc/en-us" target="_blank">Support</a></h2> <ul> <li class="minFooterShow"><a href="https://mediafire.zendesk.com/hc/en-us" target="_blank">Get Support</a></li> </ul> </div> </div>  <div id="google_translate_element"></div> <script type="text/javascript">function googleTranslateElementInit(){new google.translate.TranslateElement({pageLanguage:'en',layout:google.translate.TranslateElement.InlineLayout.HORIZONTAL,gaTrack:true,gaId:'UA-829541-1'},'google_translate_element');} </script> <script type="text/javascript">(function(){var googleTranslateScript=document.createElement('script');googleTranslateScript.type='text/javascript';googleTranslateScript.async=true;googleTranslateScript.src='//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit';(document.getElementsByTagName('head')[0]||document.getElementsByTagName('body')[0]).appendChild(googleTranslateScript);})(); </script>  </div>  <div id="subFooterWrap"> <div id="subFooter" class="wrap">  <button type="button" class="footerTabLogo" onclick="$('#footer').attr('class','tabMF');$('#google_translate_element').appendTo('#google_translate_element_dynamic');" title="About"> <span class="sr-only">About</span> </button> <button type="button" class="footerTabHelp ico30help" onclick="$('#footer').attr('class','tabMFhelp');" title="Help"> <span class="sr-only">Help</span> </button> <button type="button" class="myfilesFooterClose" onclick="$('#footer').attr('class','');"> CLOSE </button> <div id="myfilesTabMF"> <div class="footerColWrap cf"> <div class="footerCol"> <h2><a href="/about/">Company</a></h2> <ul> <li class="minFooterShow"><a href="/about/">About Us</a></li> <li><a href="/about/jobs.php">Careers</a></li> <li><a href="/press/">Press</a></li> </ul> </div> <div class="footerCol"> <h2><a href="/software/index.php">Tools</a></h2> <ul> <li class="minFooterShow"> <a href="/software/mobile/">MediaFire Mobile</a> </li> </ul> </div> <div class="footerCol"> <h2><a href="/upgrade/">Upgrade</a></h2> <ul> <li><a href="/upgrade/index.php?plan=Pro">Professional</a></li>  <li><a href="https://www.fast.io/?utm_source=mffooter">Business</a></li>  </ul> </div> <div class="footerCol" style="margin-right:0;"> <h2><a href="https://mediafire.zendesk.com/hc/en-us" target="_blank">Support</a></h2> <ul> <li class="minFooterShow"><a href="https://mediafire.zendesk.com/hc/en-us" target="_blank">Get Support</a></li> </ul> </div> </div> </div> <div class="myfilesTabHelp"> <p> Questions? <a href="/help/submit_a_ticket.php" target="_blank" tabindex="-1">Submit a ticket</a> or <a href="/help/" target="_blank">visit our Help Center</a>. </p> <div class="footerShortcuts"> <p style="margin-right:15px;">Keyboard Shortcuts:</p> <div class="footerShortcutHide"><span>U</span> = Upload</div> <div class="footerShortcutHide"><span>N</span> = New Folder</div> <div><span class="footerShortcutsWin">CTRL</span><span class="footerShortcutsMac">CMD</span> + <span>A</span> = Select All</div> <div><span>ESC</span> = Deselect</div> <div class="lastShortcut"><span>DEL</span> = Move to Trash</div> </div> </div>   <div id="google_translate_element_dynamic"></div>  <ul class="subFooterLinks"> <li id="copyrightInfo">&copy;2026 MediaFire<span> Build 121967</span></li> <li><a href="/advertising/">Advertising</a></li> <li><a href="/policies/terms_of_service.php">Terms</a></li> <li><a href="/policies/privacy_policy.php">Privacy Policy</a></li> <li><a href="/policy_violation/copyright.php">Copyright</a></li> <li><a href="/policy_violation/terms_of_service.php">Abuse</a></li> <li><a href="/credits/">Credits</a></li> <li><a href="/about/">More...</a></li> </ul> <div class="subFooterSocialWrap"> <ul id="subFooterSocial"> <li class="footerIcn"> <a href="http://www.facebook.com/mediafire" class="footerIcnFb" target="_blank" rel="noreferrer" title="MediaFire's Facebook page"> <span class="footerIcnFb"></span> </a> </li> <li class="footerIcn"> <a href="http://twitter.com/#!/mediafire" class="footerIcnTw" target="_blank" rel="noreferrer" title="MediaFire's Twitter page"> <span class="footerIcnTw"></span> </a> </li> <li class="footerIcn"> <a href="http://blog.mediafire.com/" class="footerIcnBlog" target="_blank" title="MediaFire Blog"> <span class="footerIcnBlog"></span> </a> </li> </ul> </div> </div> </div> </footer>   <div class="sandboxLabel labelRibbon">SANDBOX</div>  <footer id="simpleFooter" role="contentinfo"> <div class="wrap"> <span>&copy;2026 MediaFire&nbsp;&nbsp; <span>Build 121967</span> </span> <span style="opacity:.5;border-left:1px solid #999;margin:0 8px 0 10px;"></span> Need help? <a href="/help/submit_a_ticket.php" target="_blank">Submit a ticket</a>. </div> </footer>  <div id="page_screen">&nbsp;</div>  <iframe src="/blank.html" style="display:none;" id="userwork" name="userwork" width="0" height="0" frameborder="0"></iframe> <iframe src="/blank.html" style="display:none;" id="emailwork" name="emailwork" width="0" height="0" frameborder="0"></iframe>  <script type="text/javascript" defer>try{DoShow("notloggedin_wrapper");}catch(e){asO(e,'FTR:do_show');}try{cR();}catch(e){asO(e,'FTR:check_login');}try{$(function(){  });}catch(e){asO(e,'FTR:on_load');}try{ap(-1);}catch(e){asO(e,'FTR:set_header_tabs');}try{var gV=document.getElementById('pagename');if(gV){$('body').addClass(gV.value);}}catch(e){asO(e,'FTR:check_pagename');}try{$(function(){$('#submit_login').click(function(){$('#login_form').hide();$('#login_spinner').show();setTimeout(function(){$('#login_spinner').hide();$('#login_form').show();},60000);});});}catch(e){asO(e,'FTR:login_submit');} </script> <script type="text/javascript" defer>  $('.pig_latin').text(function(aqC,aUE){var aVr=aUE.replace(/\b(\w+?)(\w)ay\b/g,'$2$1');$(this).attr('href','mailto:'+aVr);return aVr;});var aWI= false;var bAnonPrivacyTOSAccepted=false;function aXk(){if(!aWJ){if(typeof tH.aWM==='boolean'&& !tH.aWM){aTj();}return;}if(typeof aXX!=='undefined'){if(aXX()){return true;}}if(UserLogin==0){if(!bAnonPrivacyTOSAccepted){LoadIframeLightbox('/templates/tos.php?anonymous=',720,574,false,false,true,false,true);}return false;}var aYc=new tH.Dv();aYc.aZf({success:function(data,ts,Yi){var aYS=data.response.terms_of_service;if(aYS.user_accepted_terms==='yes'){if(typeof tH.aWM==='boolean'&& !tH.aWM){aTj();}}else{if($('#modal_window_popup').is(':visible')){return false;}else{LoadIframeLightbox('/templates/tos.php?token=',720,574,false,false,true,false,true);return;}}}});};if(typeof tH.aWM==='boolean'&& !tH.aWM){aTj();}if(UserLogin||aWI){if(typeof gV!='undefined'&&gV&&gV.value&&gV.value!='tos_declined'){aXk();if(aWJ)var GLB_fTermsCheckInterval=setInterval(aXk, 30000);}} </script> 
<style type="text/css">
.CookieAcceptance {
    position: fixed;
    bottom: 0;
    left: 0;
    right: 0;
    padding: 25px;
    background: hsla(220, 21%, 12%,.95);
    border-top: 1px solid rgba(255,255,255,.1);
    color: #fff;
    font-size: 13px;
    z-index: 9999999;
}

.CookieAcceptance p {
    padding-right: 250px;
}

.CookieAcceptance p a {
    white-space: nowrap;
    color: #fff;
    text-decoration: underline;
}

.CookieAcceptance-buttons {
    position: absolute;
    right: 10px;
    top: 50%;
    transform: translateY(-50%);
    display: -ms-flexbox;
    display: flex;
    -ms-flex-align: center;
    align-items: center;
}

.CookieAcceptance-close {
    position: relative;
    height: 44px;
    width: 44px;
    opacity: .7;
}

.CookieAcceptance-close:hover,
.CookieAcceptance-close:focus {
    opacity: .5;
}

.CookieAcceptance-close span {
    position: absolute;
    height: 24px;
    width: 24px;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    background: #fff;
    border-radius: 50%;
    font-size: 0;
}

.CookieAcceptance-close span:before,
.CookieAcceptance-close span:after {
    content: '';
    position: absolute;
    height: 2px;
    width: 12px;
    background: hsl(220, 21%, 12%);
    top: 50%;
    left: 50%;
}

.CookieAcceptance-close span:before {
    transform: translate(-50%, -50%) rotate(45deg);
}

.CookieAcceptance-close span:after {
    transform: translate(-50%, -50%) rotate(-45deg);
}

.CookieAcceptance-accept {
    padding: 12px 50px;
    margin-left: 10px;
    background: #0070F0;
    background: var(--mf-blue4);
    border-radius: 4px;
    color: #fff;
    font-weight: bold;
    font-size: 14px;
}

.CookieAcceptance-accept:hover,
.CookieAcceptance-accept:focus {
    color: #fff;
    background: hsl(212, 100%, 42%);
}

@media (max-width: 575px) {
    .CookieAcceptance-buttons {
        position: static;
        transform: none;
        margin-top: 30px;
        -ms-flex-pack: end;
        justify-content: flex-end;
    }

    .CookieAcceptance p {
        padding-right: 0;
    }
}
</style>

<div id="cookie-accept-footer" class="CookieAcceptance" style="display: none;">
    <p>
MediaFire uses cookies to provide you with a personalized browsing experience. By continuing to use this site, you agree to our Privacy Policy.    </p>
    <div class="CookieAcceptance-buttons">
        <a href="#" class="CookieAcceptance-close" onclick="acceptCookieFooter(); return false;">
            <span>Dismiss</span>
        </a>
        <a href="#" class="CookieAcceptance-accept" onclick="acceptCookieFooter(); return false;">
            I Accept
        </a>
    </div>
</div>
<script type="text/javascript">
    function showCookieBanner() {
        var el = document.getElementById('cookie-accept-footer');
        if (el) el.style.display = 'block';
    }
    function acceptCookieFooter() {
        var el = document.getElementById('cookie-accept-footer');
        if (el) el.style.display = 'none';
        document.cookie = "accept-cookies=1;domain=.mediafire.com;path=/;max-age=31536000";
    }
    function doesCookieExist(cookie) {
        var match = document.cookie.match('(^|;)\\s*' + cookie + '=');
        if (match !== null) {
            return true;
        } else {
            return false;
        }
    }
    if (!doesCookieExist('accept-cookies')) {
        showCookieBanner();
    }
</script>
 <script>(function(){function c(){var b=a.contentDocument||a.contentWindow.document;if(b){var d=b.createElement('script');d.innerHTML="window.__CF$cv$params={r:'9f86e5f43d38f0a2',t:'MTc3ODIyNjg4NQ=='};var a=document.createElement('script');a.src='/cdn-cgi/challenge-platform/scripts/jsd/main.js';document.getElementsByTagName('head')[0].appendChild(a);";b.getElementsByTagName('head')[0].appendChild(d)}}if(document.body){var a=document.createElement('iframe');a.height=1;a.width=1;a.style.position='absolute';a.style.top=0;a.style.left=0;a.style.border='none';a.style.visibility='hidden';document.body.appendChild(a);if('loading'!==document.readyState)c();else if(window.addEventListener)document.addEventListener('DOMContentLoaded',c);else{var e=document.onreadystatechange||function(){};document.onreadystatechange=function(b){e(b);'loading'!==document.readyState&&(document.onreadystatechange=e,c())}}}})();</script></body> </html>